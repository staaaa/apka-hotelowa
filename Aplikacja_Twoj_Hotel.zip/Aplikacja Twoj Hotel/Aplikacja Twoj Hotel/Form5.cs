﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplikacja_Twoj_Hotel
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            openChildForm(new Form6());
        }

        // wybieranie aktywnego okna
        private Form activeForm = new Form2();
        private void openChildForm(Form childForm)
        {

            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelZarzFill.Controls.Add(childForm);
            panelZarzFill.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void btnZarzPokoj_Click(object sender, EventArgs e)
        {
            panelPrzesuwany.Location = new Point(0, 0);
            panelPrzesuwany.Size = new Size(290, 10);
            openChildForm(new Form6());
        }

        private void btnZarzPracownik_Click(object sender, EventArgs e)
        {
            panelPrzesuwany.Location = new Point(290, 0);
            panelPrzesuwany.Size = new Size(291, 10);
            openChildForm(new Form7());
        }

        private void btnZarzPrzydziel_Click(object sender, EventArgs e)
        {
            panelPrzesuwany.Location = new Point(581, 0);
            panelPrzesuwany.Size = new Size(290, 10);
            openChildForm(new Form8());
        }
    }
}
