﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplikacja_Twoj_Hotel
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            pobierzDane();
        }
        public void pobierzDane()
        {
            //pobierz dane logowania z formularza i przypisz
            string mojePolaczenie =
            "SERVER=127.0.0.1;" +
            "DATABASE=hotel;" +
            "UID=root;" +
            "PASSWORD=;";

            //wykonaj polecenie języka SQL
            string sql = "SELECT nr,stan,wymiar,wyposazenie,lozka,standard,lokator FROM pokoje";

            MySqlConnection polaczenie = new MySqlConnection(mojePolaczenie);
            //blok try-catch przechwytuje błędy
            try
            {
                //otwórz połączenie z bazą danych
                polaczenie.Open();
                //wykonaj polecenie języka SQL na danych połączeniu
                using (MySqlCommand cmdSel = new MySqlCommand(sql, polaczenie))
                {
                    DataTable dt = new DataTable();
                    //Pobierz dane i zapisz w strukturze DataTable
                    MySqlDataAdapter da = new MySqlDataAdapter(cmdSel);
                    da.Fill(dt);
                    //wpisz dane do kontrolki DATAGRID
                    dataPokoje.DataSource = dt.DefaultView;
                }

            }
            //Jeżeli wystąpi wyjątek wyrzuć go i pokaż informacje
            catch (MySql.Data.MySqlClient.MySqlException)
            {
                MessageBox.Show("Błąd logowania do bazy danych MySQL", "Błąd");
            }
            //Zamknij połączenie po wyświetleniu danych
            polaczenie.Close();
        }

        private void txtBoxPokoj_TextChanged(object sender, EventArgs e)
        {
            if (rbtn_pokoj1.Checked)
            {
                foreach (DataGridViewRow item in this.dataPokoje.Rows)
                {
                    if (dataPokoje.Rows[item.Index].Cells[0].Value.ToString() == txtBoxPokoj.Text)
                        item.Selected = true;
                }
            }
            else
            {
                foreach (DataGridViewRow item in this.dataPokoje.Rows)
                {
                    if (dataPokoje.Rows[item.Index].Cells[6].Value.ToString() == txtBoxPokoj.Text)
                        item.Selected = true;
                }
            }
        }
    }
}
