﻿
namespace Aplikacja_Twoj_Hotel
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panelSzukaj = new System.Windows.Forms.Panel();
            this.txtBoxPokoj = new System.Windows.Forms.TextBox();
            this.panelData = new System.Windows.Forms.Panel();
            this.dataPokoje = new System.Windows.Forms.DataGridView();
            this.rbtn_pokoj1 = new System.Windows.Forms.RadioButton();
            this.rbtn_pokoj2 = new System.Windows.Forms.RadioButton();
            this.panelSzukaj.SuspendLayout();
            this.panelData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataPokoje)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "WYSZUKAJ PO:";
            // 
            // panelSzukaj
            // 
            this.panelSzukaj.Controls.Add(this.rbtn_pokoj2);
            this.panelSzukaj.Controls.Add(this.rbtn_pokoj1);
            this.panelSzukaj.Controls.Add(this.txtBoxPokoj);
            this.panelSzukaj.Controls.Add(this.label1);
            this.panelSzukaj.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSzukaj.Location = new System.Drawing.Point(0, 0);
            this.panelSzukaj.Name = "panelSzukaj";
            this.panelSzukaj.Size = new System.Drawing.Size(871, 64);
            this.panelSzukaj.TabIndex = 1;
            // 
            // txtBoxPokoj
            // 
            this.txtBoxPokoj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxPokoj.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxPokoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxPokoj.Location = new System.Drawing.Point(463, 21);
            this.txtBoxPokoj.Name = "txtBoxPokoj";
            this.txtBoxPokoj.Size = new System.Drawing.Size(262, 31);
            this.txtBoxPokoj.TabIndex = 1;
            this.txtBoxPokoj.TextChanged += new System.EventHandler(this.txtBoxPokoj_TextChanged);
            // 
            // panelData
            // 
            this.panelData.Controls.Add(this.dataPokoje);
            this.panelData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelData.Location = new System.Drawing.Point(0, 64);
            this.panelData.Name = "panelData";
            this.panelData.Size = new System.Drawing.Size(871, 361);
            this.panelData.TabIndex = 2;
            // 
            // dataPokoje
            // 
            this.dataPokoje.AllowUserToAddRows = false;
            this.dataPokoje.AllowUserToDeleteRows = false;
            this.dataPokoje.AllowUserToOrderColumns = true;
            this.dataPokoje.AllowUserToResizeColumns = false;
            this.dataPokoje.AllowUserToResizeRows = false;
            this.dataPokoje.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataPokoje.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataPokoje.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.dataPokoje.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataPokoje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataPokoje.Location = new System.Drawing.Point(12, 6);
            this.dataPokoje.Name = "dataPokoje";
            this.dataPokoje.ReadOnly = true;
            this.dataPokoje.RowTemplate.Height = 25;
            this.dataPokoje.Size = new System.Drawing.Size(847, 343);
            this.dataPokoje.TabIndex = 0;
            // 
            // rbtn_pokoj1
            // 
            this.rbtn_pokoj1.AutoSize = true;
            this.rbtn_pokoj1.Location = new System.Drawing.Point(246, 27);
            this.rbtn_pokoj1.Name = "rbtn_pokoj1";
            this.rbtn_pokoj1.Size = new System.Drawing.Size(78, 19);
            this.rbtn_pokoj1.TabIndex = 2;
            this.rbtn_pokoj1.TabStop = true;
            this.rbtn_pokoj1.Text = "Nr pokoju";
            this.rbtn_pokoj1.UseVisualStyleBackColor = true;
            // 
            // rbtn_pokoj2
            // 
            this.rbtn_pokoj2.AutoSize = true;
            this.rbtn_pokoj2.Location = new System.Drawing.Point(346, 27);
            this.rbtn_pokoj2.Name = "rbtn_pokoj2";
            this.rbtn_pokoj2.Size = new System.Drawing.Size(111, 19);
            this.rbtn_pokoj2.TabIndex = 3;
            this.rbtn_pokoj2.TabStop = true;
            this.rbtn_pokoj2.Text = "Lokatorze(pesel)";
            this.rbtn_pokoj2.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(82)))), ((int)(((byte)(104)))));
            this.ClientSize = new System.Drawing.Size(871, 425);
            this.Controls.Add(this.panelData);
            this.Controls.Add(this.panelSzukaj);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form3";
            this.Text = "Form3";
            this.panelSzukaj.ResumeLayout(false);
            this.panelSzukaj.PerformLayout();
            this.panelData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataPokoje)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelSzukaj;
        private System.Windows.Forms.TextBox txtBoxPokoj;
        private System.Windows.Forms.Panel panelData;
        private System.Windows.Forms.DataGridView dataPokoje;
        private System.Windows.Forms.RadioButton rbtn_pokoj2;
        private System.Windows.Forms.RadioButton rbtn_pokoj1;
    }
}