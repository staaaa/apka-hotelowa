﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplikacja_Twoj_Hotel
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void btnPzydzielPokoj_Click(object sender, EventArgs e)
        {
            int nr = Convert.ToInt32(txtBoxNrPokoju.Text);
            string odKiedy = txtBoxOd.Text;
            string doKiedy = txtBoxDo.Text;
            string godzZameldowania = txtBoxGodzZameldowania.Text;
            string imie = txtBoxImięLok.Text;
            string nazwisko = txtBoxNazwiskoLok.Text;
            string pesel = txtBoxPeselLok.Text;
            string dataUrodzenia = txtBoxDataUroLok.Text;
            string nrTelefonu = txtBoxNrTelLok.Text;
            int iloscOsob = Convert.ToInt32(txtBoxIloscOsob.Text);
            string oplata = txtBoxCena.Text;

            string mojePolaczenie =
           "SERVER=127.0.0.1;" +
           "DATABASE=hotel;" +
           "UID=root;" +
           "PASSWORD=;";

            string sql1 = "INSERT INTO lokatorzy VALUES ('" + imie + "','" + nazwisko + "','" + dataUrodzenia + "','" + pesel + "','" + oplata + "','" + odKiedy + "','" + doKiedy + "','" + godzZameldowania + "','" + nrTelefonu + "','" + iloscOsob + "')";
            string sql2 = "UPDATE pokoje SET lokator ='" + pesel + "' WHERE nr = '" + nr + "'";
            MySqlConnection polaczenie = new MySqlConnection(mojePolaczenie);
            MySqlCommand MyCommand1 = new MySqlCommand(sql1, polaczenie);
            MySqlCommand MyCommand2 = new MySqlCommand(sql2, polaczenie);

            try
            {
                MySqlDataReader MyReader1;
                MySqlDataReader MyReader2;

                polaczenie.Open();
                MyReader1 = MyCommand1.ExecuteReader();
                polaczenie.Close();

                polaczenie.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                polaczenie.Close();
                MessageBox.Show("Poprawnie dodano pracownika do bazy danych!", "Udało się!");
            }
            catch (MySql.Data.MySqlClient.MySqlException)
            {
                MessageBox.Show("Błąd logowania do bazy danych MySQL", "Błąd");
            }
        }
    }
}
