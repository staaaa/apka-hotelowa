﻿
namespace Aplikacja_Twoj_Hotel
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelWitaj = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelStaty = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelLewy = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.labelPokoje = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelGoscie = new System.Windows.Forms.Label();
            this.labelPracownicy = new System.Windows.Forms.Label();
            this.panelWitaj.SuspendLayout();
            this.panelStaty.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelLewy.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelWitaj
            // 
            this.panelWitaj.Controls.Add(this.label1);
            this.panelWitaj.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelWitaj.Location = new System.Drawing.Point(0, 0);
            this.panelWitaj.Name = "panelWitaj";
            this.panelWitaj.Size = new System.Drawing.Size(871, 131);
            this.panelWitaj.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Exo 2", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(101, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(668, 78);
            this.label1.TabIndex = 0;
            this.label1.Text = "WITAJ W APLIKACJI TWÓJ HOTEL!\r\nOTO PODSTAWOWE STATYSTYKI TWOJEGO HOTELU:\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelStaty
            // 
            this.panelStaty.Controls.Add(this.panel2);
            this.panelStaty.Controls.Add(this.panel1);
            this.panelStaty.Controls.Add(this.panelLewy);
            this.panelStaty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelStaty.Location = new System.Drawing.Point(0, 131);
            this.panelStaty.Name = "panelStaty";
            this.panelStaty.Size = new System.Drawing.Size(871, 294);
            this.panelStaty.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(60)))), ((int)(((byte)(83)))));
            this.panel2.Controls.Add(this.labelGoscie);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(316, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(240, 240);
            this.panel2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(60)))), ((int)(((byte)(83)))));
            this.panel1.Controls.Add(this.labelPracownicy);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(610, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(240, 240);
            this.panel1.TabIndex = 1;
            // 
            // panelLewy
            // 
            this.panelLewy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(60)))), ((int)(((byte)(83)))));
            this.panelLewy.Controls.Add(this.labelPokoje);
            this.panelLewy.Controls.Add(this.label2);
            this.panelLewy.Location = new System.Drawing.Point(21, 29);
            this.panelLewy.Name = "panelLewy";
            this.panelLewy.Size = new System.Drawing.Size(240, 240);
            this.panelLewy.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Exo 2", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.label2.Location = new System.Drawing.Point(47, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 35);
            this.label2.TabIndex = 0;
            this.label2.Text = "WYNAJĘTE:";
            // 
            // labelPokoje
            // 
            this.labelPokoje.AutoSize = true;
            this.labelPokoje.Font = new System.Drawing.Font("Exo 2", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelPokoje.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.labelPokoje.Location = new System.Drawing.Point(93, 205);
            this.labelPokoje.Name = "labelPokoje";
            this.labelPokoje.Size = new System.Drawing.Size(58, 35);
            this.labelPokoje.TabIndex = 1;
            this.labelPokoje.Text = "X/Y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Exo 2", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.label4.Location = new System.Drawing.Point(68, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 35);
            this.label4.TabIndex = 2;
            this.label4.Text = "GOŚCIE:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Exo 2", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.label5.Location = new System.Drawing.Point(37, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(174, 35);
            this.label5.TabIndex = 3;
            this.label5.Text = "PRACOWNICY:";
            // 
            // labelGoscie
            // 
            this.labelGoscie.AutoSize = true;
            this.labelGoscie.Font = new System.Drawing.Font("Exo 2", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelGoscie.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.labelGoscie.Location = new System.Drawing.Point(97, 98);
            this.labelGoscie.Name = "labelGoscie";
            this.labelGoscie.Size = new System.Drawing.Size(51, 58);
            this.labelGoscie.TabIndex = 2;
            this.labelGoscie.Text = "X";
            // 
            // labelPracownicy
            // 
            this.labelPracownicy.AutoSize = true;
            this.labelPracownicy.Font = new System.Drawing.Font("Exo 2", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelPracownicy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.labelPracownicy.Location = new System.Drawing.Point(96, 98);
            this.labelPracownicy.Name = "labelPracownicy";
            this.labelPracownicy.Size = new System.Drawing.Size(51, 58);
            this.labelPracownicy.TabIndex = 3;
            this.labelPracownicy.Text = "X";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(82)))), ((int)(((byte)(104)))));
            this.ClientSize = new System.Drawing.Size(871, 425);
            this.Controls.Add(this.panelStaty);
            this.Controls.Add(this.panelWitaj);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            this.panelWitaj.ResumeLayout(false);
            this.panelWitaj.PerformLayout();
            this.panelStaty.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelLewy.ResumeLayout(false);
            this.panelLewy.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelWitaj;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelStaty;
        private System.Windows.Forms.Panel panelLewy;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelGoscie;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelPracownicy;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelPokoje;
    }
}