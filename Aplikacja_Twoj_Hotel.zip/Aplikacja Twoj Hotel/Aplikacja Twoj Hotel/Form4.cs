﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplikacja_Twoj_Hotel
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            pobierzDane();
        }
        //pobierz dane logowania z formularza i przypisz
        string mojePolaczenie =
        "SERVER=127.0.0.1;" +
        "DATABASE=hotel;" +
        "UID=root;" +
        "PASSWORD=;";

        public void pobierzDane()
        {
         
            //wykonaj polecenie języka SQL
            string sql = "SELECT id,imie,nazwisko,pesel,stanowisko FROM pracownicy";

            MySqlConnection polaczenie = new MySqlConnection(mojePolaczenie);
            //blok try-catch przechwytuje błędy
            try
            {
                //otwórz połączenie z bazą danych
                polaczenie.Open();
                //wykonaj polecenie języka SQL na danych połączeniu
                using (MySqlCommand cmdSel = new MySqlCommand(sql, polaczenie))
                {
                    DataTable dt = new DataTable();
                    //Pobierz dane i zapisz w strukturze DataTable
                    MySqlDataAdapter da = new MySqlDataAdapter(cmdSel);
                    da.Fill(dt);
                    //wpisz dane do kontrolki DATAGRID
                    dataPokoje.DataSource = dt.DefaultView;
                }

            }
            //Jeżeli wystąpi wyjątek wyrzuć go i pokaż informacje
            catch (MySql.Data.MySqlClient.MySqlException)
            {
                MessageBox.Show("Błąd logowania do bazy danych MySQL", "Błąd");
            }
            //Zamknij połączenie po wyświetleniu danych
            polaczenie.Close();
        }

        private void btn_usunPracownika_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in this.dataPokoje.SelectedRows)
            {
                int id = Convert.ToInt32(dataPokoje.Rows[item.Index].Cells[0].Value);
                dataPokoje.Rows.RemoveAt(item.Index);
                string sql = "DELETE FROM pracownicy WHERE id = '" + id + "'";
                MySqlConnection polaczenie = new MySqlConnection(mojePolaczenie);
                polaczenie.Open();
                using (MySqlCommand cmdDel = new MySqlCommand(sql, polaczenie))
                {
                    cmdDel.ExecuteNonQuery();
                }
            }
        }

        private void txtBoxPracownik_TextChanged(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in this.dataPokoje.Rows)
            {
                if (dataPokoje.Rows[item.Index].Cells[2].Value.ToString() == txtBoxPracownik.Text)
                    item.Selected = true;
            }
        }
    }
}