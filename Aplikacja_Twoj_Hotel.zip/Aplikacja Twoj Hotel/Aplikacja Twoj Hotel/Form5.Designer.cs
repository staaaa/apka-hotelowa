﻿
namespace Aplikacja_Twoj_Hotel
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelZarzPrzyciski = new System.Windows.Forms.Panel();
            this.panelPrzesuwany = new System.Windows.Forms.Panel();
            this.btnZarzPrzydziel = new System.Windows.Forms.Button();
            this.btnZarzPracownik = new System.Windows.Forms.Button();
            this.btnZarzPokoj = new System.Windows.Forms.Button();
            this.panelZarzFill = new System.Windows.Forms.Panel();
            this.panelZarzPrzyciski.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelZarzPrzyciski
            // 
            this.panelZarzPrzyciski.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(60)))), ((int)(((byte)(83)))));
            this.panelZarzPrzyciski.Controls.Add(this.panelPrzesuwany);
            this.panelZarzPrzyciski.Controls.Add(this.btnZarzPrzydziel);
            this.panelZarzPrzyciski.Controls.Add(this.btnZarzPracownik);
            this.panelZarzPrzyciski.Controls.Add(this.btnZarzPokoj);
            this.panelZarzPrzyciski.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelZarzPrzyciski.Location = new System.Drawing.Point(0, 0);
            this.panelZarzPrzyciski.Name = "panelZarzPrzyciski";
            this.panelZarzPrzyciski.Size = new System.Drawing.Size(871, 55);
            this.panelZarzPrzyciski.TabIndex = 1;
            // 
            // panelPrzesuwany
            // 
            this.panelPrzesuwany.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(38)))), ((int)(((byte)(60)))));
            this.panelPrzesuwany.Location = new System.Drawing.Point(0, 0);
            this.panelPrzesuwany.Name = "panelPrzesuwany";
            this.panelPrzesuwany.Size = new System.Drawing.Size(290, 12);
            this.panelPrzesuwany.TabIndex = 2;
            // 
            // btnZarzPrzydziel
            // 
            this.btnZarzPrzydziel.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnZarzPrzydziel.FlatAppearance.BorderSize = 0;
            this.btnZarzPrzydziel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZarzPrzydziel.Font = new System.Drawing.Font("Exo 2", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnZarzPrzydziel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnZarzPrzydziel.Location = new System.Drawing.Point(581, 0);
            this.btnZarzPrzydziel.Name = "btnZarzPrzydziel";
            this.btnZarzPrzydziel.Size = new System.Drawing.Size(290, 55);
            this.btnZarzPrzydziel.TabIndex = 7;
            this.btnZarzPrzydziel.Text = "PRZYDZIEL POKÓJ";
            this.btnZarzPrzydziel.UseVisualStyleBackColor = true;
            this.btnZarzPrzydziel.Click += new System.EventHandler(this.btnZarzPrzydziel_Click);
            // 
            // btnZarzPracownik
            // 
            this.btnZarzPracownik.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnZarzPracownik.FlatAppearance.BorderSize = 0;
            this.btnZarzPracownik.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZarzPracownik.Font = new System.Drawing.Font("Exo 2", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnZarzPracownik.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnZarzPracownik.Location = new System.Drawing.Point(290, 0);
            this.btnZarzPracownik.Name = "btnZarzPracownik";
            this.btnZarzPracownik.Size = new System.Drawing.Size(291, 55);
            this.btnZarzPracownik.TabIndex = 6;
            this.btnZarzPracownik.Text = "DODAJ PRACOWNIKA";
            this.btnZarzPracownik.UseVisualStyleBackColor = true;
            this.btnZarzPracownik.Click += new System.EventHandler(this.btnZarzPracownik_Click);
            // 
            // btnZarzPokoj
            // 
            this.btnZarzPokoj.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnZarzPokoj.FlatAppearance.BorderSize = 0;
            this.btnZarzPokoj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZarzPokoj.Font = new System.Drawing.Font("Exo 2", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnZarzPokoj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnZarzPokoj.Location = new System.Drawing.Point(0, 0);
            this.btnZarzPokoj.Name = "btnZarzPokoj";
            this.btnZarzPokoj.Size = new System.Drawing.Size(290, 55);
            this.btnZarzPokoj.TabIndex = 5;
            this.btnZarzPokoj.Text = "DODAJ POKÓJ";
            this.btnZarzPokoj.UseVisualStyleBackColor = true;
            this.btnZarzPokoj.Click += new System.EventHandler(this.btnZarzPokoj_Click);
            // 
            // panelZarzFill
            // 
            this.panelZarzFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelZarzFill.Location = new System.Drawing.Point(0, 55);
            this.panelZarzFill.Name = "panelZarzFill";
            this.panelZarzFill.Size = new System.Drawing.Size(871, 370);
            this.panelZarzFill.TabIndex = 2;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(82)))), ((int)(((byte)(104)))));
            this.ClientSize = new System.Drawing.Size(871, 425);
            this.Controls.Add(this.panelZarzFill);
            this.Controls.Add(this.panelZarzPrzyciski);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form5";
            this.Text = "Form5";
            this.panelZarzPrzyciski.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelZarzPrzyciski;
        private System.Windows.Forms.Button btnZarzPrzydziel;
        private System.Windows.Forms.Button btnZarzPracownik;
        private System.Windows.Forms.Button btnZarzPokoj;
        private System.Windows.Forms.Panel panelPrzesuwany;
        private System.Windows.Forms.Panel panelZarzFill;
    }
}