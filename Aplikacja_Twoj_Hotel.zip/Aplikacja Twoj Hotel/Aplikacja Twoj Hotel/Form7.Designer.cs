﻿
namespace Aplikacja_Twoj_Hotel
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLewo = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxImie = new System.Windows.Forms.TextBox();
            this.txtBoxNazwisko = new System.Windows.Forms.TextBox();
            this.txtBoxPesel = new System.Windows.Forms.TextBox();
            this.panelPrawo = new System.Windows.Forms.Panel();
            this.rdBtnAnimator = new System.Windows.Forms.RadioButton();
            this.rdBtnKucharz = new System.Windows.Forms.RadioButton();
            this.rdBtnSprzatacz = new System.Windows.Forms.RadioButton();
            this.rdBtnMasazysta = new System.Windows.Forms.RadioButton();
            this.rdBtnKonserwator = new System.Windows.Forms.RadioButton();
            this.rdBtnRecepcjonista = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.rdBtnKelner = new System.Windows.Forms.RadioButton();
            this.rdBtnParkingowy = new System.Windows.Forms.RadioButton();
            this.btnDodajPracownika = new System.Windows.Forms.Button();
            this.panelLewo.SuspendLayout();
            this.panelPrawo.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLewo
            // 
            this.panelLewo.Controls.Add(this.label3);
            this.panelLewo.Controls.Add(this.label2);
            this.panelLewo.Controls.Add(this.label1);
            this.panelLewo.Controls.Add(this.txtBoxImie);
            this.panelLewo.Controls.Add(this.txtBoxNazwisko);
            this.panelLewo.Controls.Add(this.txtBoxPesel);
            this.panelLewo.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLewo.Location = new System.Drawing.Point(0, 0);
            this.panelLewo.Name = "panelLewo";
            this.panelLewo.Size = new System.Drawing.Size(290, 370);
            this.panelLewo.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Exo 2", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(90, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 39);
            this.label3.TabIndex = 7;
            this.label3.Text = "PESEL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Exo 2", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(62, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 39);
            this.label2.TabIndex = 6;
            this.label2.Text = "NAZWISKO";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Exo 2", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(99, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "IMIĘ";
            // 
            // txtBoxImie
            // 
            this.txtBoxImie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxImie.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxImie.Font = new System.Drawing.Font("Exo 2", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxImie.Location = new System.Drawing.Point(12, 64);
            this.txtBoxImie.Name = "txtBoxImie";
            this.txtBoxImie.Size = new System.Drawing.Size(262, 33);
            this.txtBoxImie.TabIndex = 4;
            // 
            // txtBoxNazwisko
            // 
            this.txtBoxNazwisko.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxNazwisko.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxNazwisko.Font = new System.Drawing.Font("Exo 2", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxNazwisko.Location = new System.Drawing.Point(12, 166);
            this.txtBoxNazwisko.Name = "txtBoxNazwisko";
            this.txtBoxNazwisko.Size = new System.Drawing.Size(262, 33);
            this.txtBoxNazwisko.TabIndex = 3;
            // 
            // txtBoxPesel
            // 
            this.txtBoxPesel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxPesel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxPesel.Font = new System.Drawing.Font("Exo 2", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxPesel.Location = new System.Drawing.Point(12, 275);
            this.txtBoxPesel.Name = "txtBoxPesel";
            this.txtBoxPesel.Size = new System.Drawing.Size(262, 33);
            this.txtBoxPesel.TabIndex = 2;
            // 
            // panelPrawo
            // 
            this.panelPrawo.Controls.Add(this.btnDodajPracownika);
            this.panelPrawo.Controls.Add(this.rdBtnParkingowy);
            this.panelPrawo.Controls.Add(this.rdBtnKelner);
            this.panelPrawo.Controls.Add(this.label4);
            this.panelPrawo.Controls.Add(this.rdBtnRecepcjonista);
            this.panelPrawo.Controls.Add(this.rdBtnKonserwator);
            this.panelPrawo.Controls.Add(this.rdBtnMasazysta);
            this.panelPrawo.Controls.Add(this.rdBtnSprzatacz);
            this.panelPrawo.Controls.Add(this.rdBtnKucharz);
            this.panelPrawo.Controls.Add(this.rdBtnAnimator);
            this.panelPrawo.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelPrawo.Location = new System.Drawing.Point(290, 0);
            this.panelPrawo.Name = "panelPrawo";
            this.panelPrawo.Size = new System.Drawing.Size(581, 370);
            this.panelPrawo.TabIndex = 2;
            // 
            // rdBtnAnimator
            // 
            this.rdBtnAnimator.AutoSize = true;
            this.rdBtnAnimator.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnAnimator.Location = new System.Drawing.Point(58, 80);
            this.rdBtnAnimator.Name = "rdBtnAnimator";
            this.rdBtnAnimator.Size = new System.Drawing.Size(152, 38);
            this.rdBtnAnimator.TabIndex = 1;
            this.rdBtnAnimator.TabStop = true;
            this.rdBtnAnimator.Text = "ANIMATOR";
            this.rdBtnAnimator.UseVisualStyleBackColor = true;
            // 
            // rdBtnKucharz
            // 
            this.rdBtnKucharz.AutoSize = true;
            this.rdBtnKucharz.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnKucharz.Location = new System.Drawing.Point(58, 126);
            this.rdBtnKucharz.Name = "rdBtnKucharz";
            this.rdBtnKucharz.Size = new System.Drawing.Size(137, 38);
            this.rdBtnKucharz.TabIndex = 2;
            this.rdBtnKucharz.TabStop = true;
            this.rdBtnKucharz.Text = "KUCHARZ";
            this.rdBtnKucharz.UseVisualStyleBackColor = true;
            // 
            // rdBtnSprzatacz
            // 
            this.rdBtnSprzatacz.AutoSize = true;
            this.rdBtnSprzatacz.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnSprzatacz.Location = new System.Drawing.Point(58, 170);
            this.rdBtnSprzatacz.Name = "rdBtnSprzatacz";
            this.rdBtnSprzatacz.Size = new System.Drawing.Size(157, 38);
            this.rdBtnSprzatacz.TabIndex = 3;
            this.rdBtnSprzatacz.TabStop = true;
            this.rdBtnSprzatacz.Text = "SPRZĄTACZ";
            this.rdBtnSprzatacz.UseVisualStyleBackColor = true;
            // 
            // rdBtnMasazysta
            // 
            this.rdBtnMasazysta.AutoSize = true;
            this.rdBtnMasazysta.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnMasazysta.Location = new System.Drawing.Point(343, 80);
            this.rdBtnMasazysta.Name = "rdBtnMasazysta";
            this.rdBtnMasazysta.Size = new System.Drawing.Size(165, 38);
            this.rdBtnMasazysta.TabIndex = 4;
            this.rdBtnMasazysta.TabStop = true;
            this.rdBtnMasazysta.Text = "MASAŻYSTA";
            this.rdBtnMasazysta.UseVisualStyleBackColor = true;
            // 
            // rdBtnKonserwator
            // 
            this.rdBtnKonserwator.AutoSize = true;
            this.rdBtnKonserwator.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnKonserwator.Location = new System.Drawing.Point(343, 126);
            this.rdBtnKonserwator.Name = "rdBtnKonserwator";
            this.rdBtnKonserwator.Size = new System.Drawing.Size(202, 38);
            this.rdBtnKonserwator.TabIndex = 5;
            this.rdBtnKonserwator.TabStop = true;
            this.rdBtnKonserwator.Text = "KONSERWATOR";
            this.rdBtnKonserwator.UseVisualStyleBackColor = true;
            // 
            // rdBtnRecepcjonista
            // 
            this.rdBtnRecepcjonista.AutoSize = true;
            this.rdBtnRecepcjonista.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnRecepcjonista.Location = new System.Drawing.Point(343, 170);
            this.rdBtnRecepcjonista.Name = "rdBtnRecepcjonista";
            this.rdBtnRecepcjonista.Size = new System.Drawing.Size(206, 38);
            this.rdBtnRecepcjonista.TabIndex = 6;
            this.rdBtnRecepcjonista.TabStop = true;
            this.rdBtnRecepcjonista.Text = "RECEPCJONISTA";
            this.rdBtnRecepcjonista.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Exo 2", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(193, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(188, 39);
            this.label4.TabIndex = 8;
            this.label4.Text = "STANOWISKO";
            // 
            // rdBtnKelner
            // 
            this.rdBtnKelner.AutoSize = true;
            this.rdBtnKelner.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnKelner.Location = new System.Drawing.Point(58, 214);
            this.rdBtnKelner.Name = "rdBtnKelner";
            this.rdBtnKelner.Size = new System.Drawing.Size(118, 38);
            this.rdBtnKelner.TabIndex = 9;
            this.rdBtnKelner.TabStop = true;
            this.rdBtnKelner.Text = "KELNER";
            this.rdBtnKelner.UseVisualStyleBackColor = true;
            // 
            // rdBtnParkingowy
            // 
            this.rdBtnParkingowy.AutoSize = true;
            this.rdBtnParkingowy.Font = new System.Drawing.Font("Exo 2", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnParkingowy.Location = new System.Drawing.Point(343, 214);
            this.rdBtnParkingowy.Name = "rdBtnParkingowy";
            this.rdBtnParkingowy.Size = new System.Drawing.Size(199, 38);
            this.rdBtnParkingowy.TabIndex = 10;
            this.rdBtnParkingowy.TabStop = true;
            this.rdBtnParkingowy.Text = "PARKNINGOWY";
            this.rdBtnParkingowy.UseVisualStyleBackColor = true;
            // 
            // btnDodajPracownika
            // 
            this.btnDodajPracownika.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(60)))), ((int)(((byte)(83)))));
            this.btnDodajPracownika.FlatAppearance.BorderSize = 0;
            this.btnDodajPracownika.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDodajPracownika.Font = new System.Drawing.Font("Exo 2", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDodajPracownika.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnDodajPracownika.Location = new System.Drawing.Point(131, 276);
            this.btnDodajPracownika.Name = "btnDodajPracownika";
            this.btnDodajPracownika.Size = new System.Drawing.Size(314, 82);
            this.btnDodajPracownika.TabIndex = 11;
            this.btnDodajPracownika.Text = "DODAJ PRACOWNIKA";
            this.btnDodajPracownika.UseVisualStyleBackColor = false;
            this.btnDodajPracownika.Click += new System.EventHandler(this.btnDodajPracownika_Click);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(82)))), ((int)(((byte)(104)))));
            this.ClientSize = new System.Drawing.Size(871, 370);
            this.Controls.Add(this.panelPrawo);
            this.Controls.Add(this.panelLewo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form7";
            this.Text = "Form7";
            this.panelLewo.ResumeLayout(false);
            this.panelLewo.PerformLayout();
            this.panelPrawo.ResumeLayout(false);
            this.panelPrawo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLewo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxImie;
        private System.Windows.Forms.TextBox txtBoxNazwisko;
        private System.Windows.Forms.TextBox txtBoxPesel;
        private System.Windows.Forms.Panel panelPrawo;
        private System.Windows.Forms.RadioButton rdBtnParkingowy;
        private System.Windows.Forms.RadioButton rdBtnKelner;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdBtnRecepcjonista;
        private System.Windows.Forms.RadioButton rdBtnKonserwator;
        private System.Windows.Forms.RadioButton rdBtnMasazysta;
        private System.Windows.Forms.RadioButton rdBtnSprzatacz;
        private System.Windows.Forms.RadioButton rdBtnKucharz;
        private System.Windows.Forms.RadioButton rdBtnAnimator;
        private System.Windows.Forms.Button btnDodajPracownika;
    }
}