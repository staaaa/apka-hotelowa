﻿
namespace Aplikacja_Twoj_Hotel
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_usunPracownika = new System.Windows.Forms.Button();
            this.txtBoxPracownik = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelData = new System.Windows.Forms.Panel();
            this.dataPokoje = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panelData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataPokoje)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_usunPracownika);
            this.panel1.Controls.Add(this.txtBoxPracownik);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(871, 64);
            this.panel1.TabIndex = 1;
            // 
            // btn_usunPracownika
            // 
            this.btn_usunPracownika.Location = new System.Drawing.Point(680, 25);
            this.btn_usunPracownika.Name = "btn_usunPracownika";
            this.btn_usunPracownika.Size = new System.Drawing.Size(154, 23);
            this.btn_usunPracownika.TabIndex = 2;
            this.btn_usunPracownika.Text = "Usuń pracownika";
            this.btn_usunPracownika.UseVisualStyleBackColor = true;
            this.btn_usunPracownika.Click += new System.EventHandler(this.btn_usunPracownika_Click);
            // 
            // txtBoxPracownik
            // 
            this.txtBoxPracownik.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxPracownik.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxPracownik.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxPracownik.Location = new System.Drawing.Point(368, 21);
            this.txtBoxPracownik.Name = "txtBoxPracownik";
            this.txtBoxPracownik.Size = new System.Drawing.Size(262, 31);
            this.txtBoxPracownik.TabIndex = 2;
            this.txtBoxPracownik.TextChanged += new System.EventHandler(this.txtBoxPracownik_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "WYSZUKAJ PO NAZWISKU:";
            // 
            // panelData
            // 
            this.panelData.Controls.Add(this.dataPokoje);
            this.panelData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelData.Location = new System.Drawing.Point(0, 64);
            this.panelData.Name = "panelData";
            this.panelData.Size = new System.Drawing.Size(871, 361);
            this.panelData.TabIndex = 2;
            // 
            // dataPokoje
            // 
            this.dataPokoje.AllowUserToAddRows = false;
            this.dataPokoje.AllowUserToDeleteRows = false;
            this.dataPokoje.AllowUserToOrderColumns = true;
            this.dataPokoje.AllowUserToResizeColumns = false;
            this.dataPokoje.AllowUserToResizeRows = false;
            this.dataPokoje.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataPokoje.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataPokoje.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.dataPokoje.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataPokoje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataPokoje.Location = new System.Drawing.Point(12, 9);
            this.dataPokoje.Name = "dataPokoje";
            this.dataPokoje.ReadOnly = true;
            this.dataPokoje.RowTemplate.Height = 25;
            this.dataPokoje.Size = new System.Drawing.Size(847, 343);
            this.dataPokoje.TabIndex = 1;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(82)))), ((int)(((byte)(104)))));
            this.ClientSize = new System.Drawing.Size(871, 425);
            this.Controls.Add(this.panelData);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form4";
            this.Text = "Form4";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataPokoje)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxPracownik;
        private System.Windows.Forms.Panel panelData;
        private System.Windows.Forms.DataGridView dataPokoje;
        private System.Windows.Forms.Button btn_usunPracownika;
    }
}