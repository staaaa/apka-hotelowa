﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikacja_Twoj_Hotel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            openChildForm(new Form2());
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]

        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        // Zegar na pasku
        private void Clock_Tick(object sender, EventArgs e)
        {
            labelCzas.Text = (DateTime.Now).ToString();
        }

        // Przyciski od paska
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                this.WindowState = FormWindowState.Maximized;
            else
                this.WindowState = FormWindowState.Normal;
        }
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }


        // Funkcje odpowiadające za przesuwanie aplikacji
        private void panelGora_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void labelCzas_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void labelZegar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panelTime_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        // wybieranie aktywnego okna
        private Form activeForm = new Form2();
        private void openChildForm(Form childForm)
        {

            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelFill.Controls.Add(childForm);
            panelFill.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        // przyciski odpowiadające poszczególnym oknom
        private void btnMenu_Click(object sender, EventArgs e)
        {
            openChildForm(new Form2());
            panelZaznacz.Location = new Point(0, 0);
            panelZaznacz.Size = new Size(217, 10);
        }

        private void btnPokoje_Click(object sender, EventArgs e)
        {
            openChildForm(new Form3());
            panelZaznacz.Location = new Point(217, 0);
            panelZaznacz.Size = new Size(218, 10);
        }

        private void btnPracownicy_Click(object sender, EventArgs e)
        {
            openChildForm(new Form4());
            panelZaznacz.Location = new Point(435, 0);
            panelZaznacz.Size = new Size(218, 10);
        }

        private void btnZarzadzanie_Click(object sender, EventArgs e)
        {
            openChildForm(new Form5());
            panelZaznacz.Location = new Point(653, 0);
            panelZaznacz.Size = new Size(218, 10);
        }
    }
}
