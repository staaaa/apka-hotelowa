﻿
namespace Aplikacja_Twoj_Hotel
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxNr = new System.Windows.Forms.TextBox();
            this.txtBoxWymiar = new System.Windows.Forms.TextBox();
            this.txtBoxLozka = new System.Windows.Forms.TextBox();
            this.panelSrodek = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.chBoxBalkon = new System.Windows.Forms.CheckBox();
            this.chBoxCzajnik = new System.Windows.Forms.CheckBox();
            this.chBoxKuchenka = new System.Windows.Forms.CheckBox();
            this.chBoxMikrofala = new System.Windows.Forms.CheckBox();
            this.chBoxKlimatyzacja = new System.Windows.Forms.CheckBox();
            this.chBoxSuszarka = new System.Windows.Forms.CheckBox();
            this.chBoxPralka = new System.Windows.Forms.CheckBox();
            this.rdBtnZwykleM = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.rdBtnApartament = new System.Windows.Forms.RadioButton();
            this.panelPrawy = new System.Windows.Forms.Panel();
            this.btnDodajPokoj = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panelSrodek.SuspendLayout();
            this.panelPrawy.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtBoxNr);
            this.panel1.Controls.Add(this.txtBoxWymiar);
            this.panel1.Controls.Add(this.txtBoxLozka);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(290, 370);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(54, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 31);
            this.label3.TabIndex = 7;
            this.label3.Text = "ILOŚĆ ŁÓŻEK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(28, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 31);
            this.label2.TabIndex = 6;
            this.label2.Text = "WYMIAR POKOJU";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(65, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 31);
            this.label1.TabIndex = 5;
            this.label1.Text = "NR POKOJU";
            // 
            // txtBoxNr
            // 
            this.txtBoxNr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxNr.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxNr.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxNr.Location = new System.Drawing.Point(12, 64);
            this.txtBoxNr.Name = "txtBoxNr";
            this.txtBoxNr.Size = new System.Drawing.Size(262, 31);
            this.txtBoxNr.TabIndex = 4;
            // 
            // txtBoxWymiar
            // 
            this.txtBoxWymiar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxWymiar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxWymiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxWymiar.Location = new System.Drawing.Point(12, 166);
            this.txtBoxWymiar.Name = "txtBoxWymiar";
            this.txtBoxWymiar.Size = new System.Drawing.Size(262, 31);
            this.txtBoxWymiar.TabIndex = 3;
            // 
            // txtBoxLozka
            // 
            this.txtBoxLozka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.txtBoxLozka.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxLozka.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBoxLozka.Location = new System.Drawing.Point(12, 275);
            this.txtBoxLozka.Name = "txtBoxLozka";
            this.txtBoxLozka.Size = new System.Drawing.Size(262, 31);
            this.txtBoxLozka.TabIndex = 2;
            // 
            // panelSrodek
            // 
            this.panelSrodek.Controls.Add(this.label5);
            this.panelSrodek.Controls.Add(this.chBoxBalkon);
            this.panelSrodek.Controls.Add(this.chBoxCzajnik);
            this.panelSrodek.Controls.Add(this.chBoxKuchenka);
            this.panelSrodek.Controls.Add(this.chBoxMikrofala);
            this.panelSrodek.Controls.Add(this.chBoxKlimatyzacja);
            this.panelSrodek.Controls.Add(this.chBoxSuszarka);
            this.panelSrodek.Controls.Add(this.chBoxPralka);
            this.panelSrodek.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSrodek.Location = new System.Drawing.Point(290, 0);
            this.panelSrodek.Name = "panelSrodek";
            this.panelSrodek.Size = new System.Drawing.Size(291, 370);
            this.panelSrodek.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(15, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(299, 31);
            this.label5.TabIndex = 10;
            this.label5.Text = "STANDARD POKOJU";
            // 
            // chBoxBalkon
            // 
            this.chBoxBalkon.AutoSize = true;
            this.chBoxBalkon.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chBoxBalkon.Location = new System.Drawing.Point(15, 324);
            this.chBoxBalkon.Name = "chBoxBalkon";
            this.chBoxBalkon.Size = new System.Drawing.Size(135, 33);
            this.chBoxBalkon.TabIndex = 17;
            this.chBoxBalkon.Text = "BALKON";
            this.chBoxBalkon.UseVisualStyleBackColor = true;
            // 
            // chBoxCzajnik
            // 
            this.chBoxCzajnik.AutoSize = true;
            this.chBoxCzajnik.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chBoxCzajnik.Location = new System.Drawing.Point(15, 64);
            this.chBoxCzajnik.Name = "chBoxCzajnik";
            this.chBoxCzajnik.Size = new System.Drawing.Size(137, 33);
            this.chBoxCzajnik.TabIndex = 11;
            this.chBoxCzajnik.Text = "CZAJNIK";
            this.chBoxCzajnik.UseVisualStyleBackColor = true;
            // 
            // chBoxKuchenka
            // 
            this.chBoxKuchenka.AutoSize = true;
            this.chBoxKuchenka.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chBoxKuchenka.Location = new System.Drawing.Point(15, 108);
            this.chBoxKuchenka.Name = "chBoxKuchenka";
            this.chBoxKuchenka.Size = new System.Drawing.Size(172, 33);
            this.chBoxKuchenka.TabIndex = 12;
            this.chBoxKuchenka.Text = "KUCHENKA";
            this.chBoxKuchenka.UseVisualStyleBackColor = true;
            // 
            // chBoxMikrofala
            // 
            this.chBoxMikrofala.AutoSize = true;
            this.chBoxMikrofala.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chBoxMikrofala.Location = new System.Drawing.Point(15, 152);
            this.chBoxMikrofala.Name = "chBoxMikrofala";
            this.chBoxMikrofala.Size = new System.Drawing.Size(177, 33);
            this.chBoxMikrofala.TabIndex = 13;
            this.chBoxMikrofala.Text = "MIKROFALA";
            this.chBoxMikrofala.UseVisualStyleBackColor = true;
            // 
            // chBoxKlimatyzacja
            // 
            this.chBoxKlimatyzacja.AutoSize = true;
            this.chBoxKlimatyzacja.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chBoxKlimatyzacja.Location = new System.Drawing.Point(15, 280);
            this.chBoxKlimatyzacja.Name = "chBoxKlimatyzacja";
            this.chBoxKlimatyzacja.Size = new System.Drawing.Size(219, 33);
            this.chBoxKlimatyzacja.TabIndex = 16;
            this.chBoxKlimatyzacja.Text = "KLIMATYZACJA";
            this.chBoxKlimatyzacja.UseVisualStyleBackColor = true;
            // 
            // chBoxSuszarka
            // 
            this.chBoxSuszarka.AutoSize = true;
            this.chBoxSuszarka.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chBoxSuszarka.Location = new System.Drawing.Point(15, 196);
            this.chBoxSuszarka.Name = "chBoxSuszarka";
            this.chBoxSuszarka.Size = new System.Drawing.Size(166, 33);
            this.chBoxSuszarka.TabIndex = 14;
            this.chBoxSuszarka.Text = "SUSZARKA";
            this.chBoxSuszarka.UseVisualStyleBackColor = true;
            // 
            // chBoxPralka
            // 
            this.chBoxPralka.AutoSize = true;
            this.chBoxPralka.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chBoxPralka.Location = new System.Drawing.Point(15, 239);
            this.chBoxPralka.Name = "chBoxPralka";
            this.chBoxPralka.Size = new System.Drawing.Size(130, 33);
            this.chBoxPralka.TabIndex = 15;
            this.chBoxPralka.Text = "PRALKA";
            this.chBoxPralka.UseVisualStyleBackColor = true;
            // 
            // rdBtnZwykleM
            // 
            this.rdBtnZwykleM.AutoSize = true;
            this.rdBtnZwykleM.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnZwykleM.Location = new System.Drawing.Point(17, 159);
            this.rdBtnZwykleM.Name = "rdBtnZwykleM";
            this.rdBtnZwykleM.Size = new System.Drawing.Size(294, 33);
            this.rdBtnZwykleM.TabIndex = 9;
            this.rdBtnZwykleM.Text = "ZWYKŁE MIESZKANIE";
            this.rdBtnZwykleM.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(17, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(299, 31);
            this.label4.TabIndex = 8;
            this.label4.Text = "STANDARD POKOJU";
            // 
            // rdBtnApartament
            // 
            this.rdBtnApartament.AutoSize = true;
            this.rdBtnApartament.Checked = true;
            this.rdBtnApartament.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rdBtnApartament.Location = new System.Drawing.Point(54, 101);
            this.rdBtnApartament.Name = "rdBtnApartament";
            this.rdBtnApartament.Size = new System.Drawing.Size(205, 33);
            this.rdBtnApartament.TabIndex = 0;
            this.rdBtnApartament.TabStop = true;
            this.rdBtnApartament.Text = "APARTAMENT";
            this.rdBtnApartament.UseVisualStyleBackColor = true;
            // 
            // panelPrawy
            // 
            this.panelPrawy.Controls.Add(this.btnDodajPokoj);
            this.panelPrawy.Controls.Add(this.rdBtnZwykleM);
            this.panelPrawy.Controls.Add(this.label4);
            this.panelPrawy.Controls.Add(this.rdBtnApartament);
            this.panelPrawy.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelPrawy.Location = new System.Drawing.Point(581, 0);
            this.panelPrawy.Name = "panelPrawy";
            this.panelPrawy.Size = new System.Drawing.Size(290, 370);
            this.panelPrawy.TabIndex = 2;
            // 
            // btnDodajPokoj
            // 
            this.btnDodajPokoj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(60)))), ((int)(((byte)(83)))));
            this.btnDodajPokoj.FlatAppearance.BorderSize = 0;
            this.btnDodajPokoj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDodajPokoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDodajPokoj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnDodajPokoj.Location = new System.Drawing.Point(17, 280);
            this.btnDodajPokoj.Name = "btnDodajPokoj";
            this.btnDodajPokoj.Size = new System.Drawing.Size(261, 82);
            this.btnDodajPokoj.TabIndex = 10;
            this.btnDodajPokoj.Text = "DODAJ POKÓJ";
            this.btnDodajPokoj.UseVisualStyleBackColor = false;
            this.btnDodajPokoj.Click += new System.EventHandler(this.btnDodajPokoj_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(82)))), ((int)(((byte)(104)))));
            this.ClientSize = new System.Drawing.Size(871, 370);
            this.Controls.Add(this.panelPrawy);
            this.Controls.Add(this.panelSrodek);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form6";
            this.Text = "Form6";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelSrodek.ResumeLayout(false);
            this.panelSrodek.PerformLayout();
            this.panelPrawy.ResumeLayout(false);
            this.panelPrawy.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelSrodek;
        private System.Windows.Forms.Panel panelPrawy;
        private System.Windows.Forms.TextBox txtBoxNr;
        private System.Windows.Forms.TextBox txtBoxWymiar;
        private System.Windows.Forms.TextBox txtBoxLozka;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdBtnZwykleM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdBtnApartament;
        private System.Windows.Forms.CheckBox chBoxCzajnik;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox chBoxBalkon;
        private System.Windows.Forms.CheckBox chBoxKlimatyzacja;
        private System.Windows.Forms.CheckBox chBoxPralka;
        private System.Windows.Forms.CheckBox chBoxSuszarka;
        private System.Windows.Forms.CheckBox chBoxMikrofala;
        private System.Windows.Forms.CheckBox chBoxKuchenka;
        private System.Windows.Forms.Button btnDodajPokoj;
    }
}