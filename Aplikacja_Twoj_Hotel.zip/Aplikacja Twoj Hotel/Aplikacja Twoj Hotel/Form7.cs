﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplikacja_Twoj_Hotel
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void btnDodajPracownika_Click(object sender, EventArgs e)
        {
            // dane logowania
            string mojePolaczenie =
           "SERVER=127.0.0.1;" +
           "DATABASE=hotel;" +
           "UID=root;" +
           "PASSWORD=;";

            string imie = txtBoxImie.Text;
            string nazwisko = txtBoxNazwisko.Text;
            string pesel = txtBoxPesel.Text;
            string stanowisko = "";

            if (rdBtnAnimator.Checked == true)
            {
                stanowisko = "Animator";
            }
            else if(rdBtnKelner.Checked == true)
            {
                stanowisko = "Kelner";
            }
            else if (rdBtnKonserwator.Checked == true)
            {
                stanowisko = "Konserwator";
            }
            else if (rdBtnKucharz.Checked == true)
            {
                stanowisko = "Kucharz";
            }
            else if (rdBtnMasazysta.Checked == true)
            {
                stanowisko = "Masażysta";
            }
            else if (rdBtnParkingowy.Checked == true)
            {
                stanowisko = "Parkingowy";
            }
            else if (rdBtnRecepcjonista.Checked == true)
            {
                stanowisko = "Recepcjonista";
            }
            else if (rdBtnSprzatacz.Checked == true)
            {
                stanowisko = "Sprzątacz";
            }

            string sql = "INSERT INTO pracownicy (imie,nazwisko,pesel,stanowisko) VALUES ('" + imie + "','" + nazwisko + "','" + pesel + "','" + stanowisko + "') ";
            MySqlConnection polaczenie = new MySqlConnection(mojePolaczenie);
            MySqlCommand MyCommand = new MySqlCommand(sql, polaczenie);
            try
            {
                MySqlDataReader MyReader;
                polaczenie.Open();
                MyReader = MyCommand.ExecuteReader();
                MessageBox.Show("Poprawnie dodano pracownika do bazy danych!", "Udało się!");
            }
            catch (MySql.Data.MySqlClient.MySqlException)
            {
                MessageBox.Show("Błąd logowania do bazy danych MySQL", "Błąd");
            }
            polaczenie.Close();
        }
    }
}
