﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplikacja_Twoj_Hotel
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void btnDodajPokoj_Click(object sender, EventArgs e)
        {
            // dane logowania
            string mojePolaczenie =
           "SERVER=127.0.0.1;" +
           "DATABASE=hotel;" +
           "UID=root;" +
           "PASSWORD=;";

            int nr = Convert.ToInt16(txtBoxNr.Text);
            float wymiar = float.Parse(txtBoxWymiar.Text);
            int lozka = Convert.ToInt32(txtBoxLozka.Text);
            string[] wyposazenie = new string[] { "0", "0", "0", "0", "0", "0", "0" };
            string standard;
            if (chBoxCzajnik.Checked == true)
            {
                wyposazenie[0] = "1";
            }
            if (chBoxKuchenka.Checked == true)
            {
                wyposazenie[1] = "1";
            }
            if (chBoxMikrofala.Checked == true)
            {
                wyposazenie[2] = "1";
            }
            if (chBoxSuszarka.Checked == true)
            {
                wyposazenie[3] = "1";
            }
            if (chBoxPralka.Checked == true)
            {
                wyposazenie[4] = "1";
            }
            if (chBoxKlimatyzacja.Checked == true)
            {
                wyposazenie[5] = "1";
            }
            if (chBoxBalkon.Checked == true)
            {
                wyposazenie[6] = "1";
            }

            if (rdBtnApartament.Checked == true)
            {
                standard = "Apartament";
            }
            else standard = "Standard";

            string wypo = (wyposazenie[0] + wyposazenie[1] + wyposazenie[2] + wyposazenie[3] + wyposazenie[4] + wyposazenie[5] + wyposazenie[6]);

            string sql1 = "INSERT INTO pokoje (nr,wymiar,wyposazenie,lozka,standard) VALUES ('" + nr + "','" + wymiar + "','" + wypo + "','" + lozka + "','" + standard + "') ";
            string sql2 = "SELECT nr FROM pokoje";

            MySqlConnection polaczenie = new MySqlConnection(mojePolaczenie);
            MySqlCommand MyCommand1 = new MySqlCommand(sql1, polaczenie);
            MySqlCommand MyCommand2 = new MySqlCommand(sql2, polaczenie);
            try
            {
                MySqlDataReader MyReader1;
                MySqlDataReader MyReader2;
                int i = 0;
                int[] numery = new int[100000];
                bool znaleziono = false;
                polaczenie.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                while (MyReader2.Read())
                {
                    numery[i] = Convert.ToInt32(MyReader2[0]);
                    i++;
                }
                for(int j = 0; j < i; j++)
                {
                    if(numery[j] == nr)
                    {
                        MessageBox.Show("Podano wcześniej użyty numer pokoju.", "Błąd");
                        znaleziono = true;   
                    }
                }
                polaczenie.Close();
                polaczenie.Open();
                if(znaleziono == false)
                {
                    MyReader1 = MyCommand1.ExecuteReader();
                    MessageBox.Show("Poprawnie dodano pokój do bazy danych!", "Udało się!");
                }
            }
            catch (MySql.Data.MySqlClient.MySqlException)
            {
                MessageBox.Show("Błąd logowania do bazy danych MySQL", "Błąd");
            }
            polaczenie.Close();
        }
    }
}
