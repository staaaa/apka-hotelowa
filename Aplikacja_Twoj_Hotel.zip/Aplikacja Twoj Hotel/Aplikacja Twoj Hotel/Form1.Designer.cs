﻿
namespace Aplikacja_Twoj_Hotel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelGora = new System.Windows.Forms.Panel();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.panelTime = new System.Windows.Forms.Panel();
            this.labelCzas = new System.Windows.Forms.Label();
            this.labelZegar = new System.Windows.Forms.Label();
            this.panelPrzyciski = new System.Windows.Forms.Panel();
            this.panelZaznacz = new System.Windows.Forms.Panel();
            this.btnZarzadzanie = new System.Windows.Forms.Button();
            this.btnPracownicy = new System.Windows.Forms.Button();
            this.btnPokoje = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.panelFill = new System.Windows.Forms.Panel();
            this.Zegar = new System.Windows.Forms.Timer(this.components);
            this.panelGora.SuspendLayout();
            this.panelTime.SuspendLayout();
            this.panelPrzyciski.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelGora
            // 
            this.panelGora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(38)))), ((int)(((byte)(60)))));
            this.panelGora.Controls.Add(this.btnMinimize);
            this.panelGora.Controls.Add(this.btnMaximize);
            this.panelGora.Controls.Add(this.btnExit);
            this.panelGora.Controls.Add(this.panelTime);
            this.panelGora.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelGora.Location = new System.Drawing.Point(0, 0);
            this.panelGora.Name = "panelGora";
            this.panelGora.Size = new System.Drawing.Size(871, 50);
            this.panelGora.TabIndex = 0;
            this.panelGora.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelGora_MouseDown);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMinimize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnMinimize.Location = new System.Drawing.Point(721, 0);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(50, 50);
            this.btnMinimize.TabIndex = 3;
            this.btnMinimize.Text = "X";
            this.btnMinimize.UseVisualStyleBackColor = true;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnMaximize.FlatAppearance.BorderSize = 0;
            this.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximize.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMaximize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnMaximize.Location = new System.Drawing.Point(771, 0);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(50, 50);
            this.btnMaximize.TabIndex = 2;
            this.btnMaximize.Text = "X";
            this.btnMaximize.UseVisualStyleBackColor = true;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // btnExit
            // 
            this.btnExit.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnExit.Location = new System.Drawing.Point(821, 0);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(50, 50);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panelTime
            // 
            this.panelTime.Controls.Add(this.labelCzas);
            this.panelTime.Controls.Add(this.labelZegar);
            this.panelTime.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTime.Location = new System.Drawing.Point(0, 0);
            this.panelTime.Name = "panelTime";
            this.panelTime.Size = new System.Drawing.Size(383, 50);
            this.panelTime.TabIndex = 0;
            this.panelTime.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTime_MouseDown);
            // 
            // labelCzas
            // 
            this.labelCzas.AutoSize = true;
            this.labelCzas.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelCzas.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelCzas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.labelCzas.Location = new System.Drawing.Point(51, 0);
            this.labelCzas.Name = "labelCzas";
            this.labelCzas.Size = new System.Drawing.Size(297, 35);
            this.labelCzas.TabIndex = 1;
            this.labelCzas.Text = "22.02.2022 19:54:50";
            this.labelCzas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.labelCzas_MouseDown);
            // 
            // labelZegar
            // 
            this.labelZegar.AutoSize = true;
            this.labelZegar.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelZegar.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelZegar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.labelZegar.Location = new System.Drawing.Point(0, 0);
            this.labelZegar.Name = "labelZegar";
            this.labelZegar.Size = new System.Drawing.Size(51, 51);
            this.labelZegar.TabIndex = 0;
            this.labelZegar.Text = "P";
            this.labelZegar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.labelZegar_MouseDown);
            // 
            // panelPrzyciski
            // 
            this.panelPrzyciski.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(60)))), ((int)(((byte)(83)))));
            this.panelPrzyciski.Controls.Add(this.panelZaznacz);
            this.panelPrzyciski.Controls.Add(this.btnZarzadzanie);
            this.panelPrzyciski.Controls.Add(this.btnPracownicy);
            this.panelPrzyciski.Controls.Add(this.btnPokoje);
            this.panelPrzyciski.Controls.Add(this.btnMenu);
            this.panelPrzyciski.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPrzyciski.Location = new System.Drawing.Point(0, 50);
            this.panelPrzyciski.Name = "panelPrzyciski";
            this.panelPrzyciski.Size = new System.Drawing.Size(871, 70);
            this.panelPrzyciski.TabIndex = 1;
            // 
            // panelZaznacz
            // 
            this.panelZaznacz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(38)))), ((int)(((byte)(60)))));
            this.panelZaznacz.Location = new System.Drawing.Point(0, 0);
            this.panelZaznacz.Name = "panelZaznacz";
            this.panelZaznacz.Size = new System.Drawing.Size(217, 10);
            this.panelZaznacz.TabIndex = 8;
            // 
            // btnZarzadzanie
            // 
            this.btnZarzadzanie.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnZarzadzanie.FlatAppearance.BorderSize = 0;
            this.btnZarzadzanie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZarzadzanie.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnZarzadzanie.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnZarzadzanie.Location = new System.Drawing.Point(653, 0);
            this.btnZarzadzanie.Name = "btnZarzadzanie";
            this.btnZarzadzanie.Size = new System.Drawing.Size(217, 70);
            this.btnZarzadzanie.TabIndex = 7;
            this.btnZarzadzanie.Text = "ZARZĄDZANIE";
            this.btnZarzadzanie.UseVisualStyleBackColor = true;
            this.btnZarzadzanie.Click += new System.EventHandler(this.btnZarzadzanie_Click);
            // 
            // btnPracownicy
            // 
            this.btnPracownicy.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnPracownicy.FlatAppearance.BorderSize = 0;
            this.btnPracownicy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPracownicy.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPracownicy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnPracownicy.Location = new System.Drawing.Point(435, 0);
            this.btnPracownicy.Name = "btnPracownicy";
            this.btnPracownicy.Size = new System.Drawing.Size(218, 70);
            this.btnPracownicy.TabIndex = 6;
            this.btnPracownicy.Text = "PRACOWNICY";
            this.btnPracownicy.UseVisualStyleBackColor = true;
            this.btnPracownicy.Click += new System.EventHandler(this.btnPracownicy_Click);
            // 
            // btnPokoje
            // 
            this.btnPokoje.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnPokoje.FlatAppearance.BorderSize = 0;
            this.btnPokoje.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPokoje.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPokoje.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnPokoje.Location = new System.Drawing.Point(217, 0);
            this.btnPokoje.Name = "btnPokoje";
            this.btnPokoje.Size = new System.Drawing.Size(218, 70);
            this.btnPokoje.TabIndex = 5;
            this.btnPokoje.Text = "POKOJE";
            this.btnPokoje.UseVisualStyleBackColor = true;
            this.btnPokoje.Click += new System.EventHandler(this.btnPokoje_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(192)))), ((int)(((byte)(210)))));
            this.btnMenu.Location = new System.Drawing.Point(0, 0);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(217, 70);
            this.btnMenu.TabIndex = 4;
            this.btnMenu.Text = "MENU";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // panelFill
            // 
            this.panelFill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(82)))), ((int)(((byte)(104)))));
            this.panelFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFill.Location = new System.Drawing.Point(0, 120);
            this.panelFill.Name = "panelFill";
            this.panelFill.Size = new System.Drawing.Size(871, 425);
            this.panelFill.TabIndex = 2;
            // 
            // Zegar
            // 
            this.Zegar.Enabled = true;
            this.Zegar.Interval = 1000;
            this.Zegar.Tick += new System.EventHandler(this.Clock_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 545);
            this.Controls.Add(this.panelFill);
            this.Controls.Add(this.panelPrzyciski);
            this.Controls.Add(this.panelGora);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelGora.ResumeLayout(false);
            this.panelTime.ResumeLayout(false);
            this.panelTime.PerformLayout();
            this.panelPrzyciski.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGora;
        private System.Windows.Forms.Panel panelTime;
        private System.Windows.Forms.Label labelCzas;
        private System.Windows.Forms.Label labelZegar;
        private System.Windows.Forms.Panel panelPrzyciski;
        private System.Windows.Forms.Panel panelFill;
        private System.Windows.Forms.Timer Zegar;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnZarzadzanie;
        private System.Windows.Forms.Button btnPracownicy;
        private System.Windows.Forms.Button btnPokoje;
        private System.Windows.Forms.Panel panelZaznacz;
    }
}

